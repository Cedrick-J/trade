import datetime
from time import sleep
from functions import *

lastPrediction = ""
while True:
    prediction = getPrediction()
    date = datetime.datetime.now();

    log = open("log2.txt","a") 
    log.write('\n'+date.strftime("%Y-%m-%d %H:%M:%S")+':\n'+"  Prediction :"+prediction+
    "\n  lastPrediction => "+lastPrediction+'\n')
    log.close();
    
    lastPrediction = prediction;
    checkDirection(prediction);
    sleep(2700);